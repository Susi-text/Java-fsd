package project2;

import java.util.ArrayList;

public class searchElement {
	 public static void main(String[] args) {
	        
	        ArrayList<String> emailID = new ArrayList<String>();
	        
	        emailID.add("susi.m@gmail.com");
	        emailID.add("lee.k@gmail.com");
	        emailID.add("ria.h@gmail.com");
	        emailID.add("max.n@gmail.com");
	        emailID.add("hennry.f@gmail.com");
	        emailID.add("laura.k@gmail.com");
	        emailID.add("soffy.b@gmail.com");
	        
	   
	        String searcElement = "ria.h@gmail.com";
	        
	                for(int i=0; i<emailID.size(); i++) {
	                    
	                    System.out.println(emailID.get(i));
	                    
	                    if(searcElement==emailID.get(i)) {
	                        
	                        System.out.println("\n");
	                        
	                        System.out.println("email ID" + searcElement + "found");
	                        
	                        break;
	                        
	                    }
	                }

	    }

	}


