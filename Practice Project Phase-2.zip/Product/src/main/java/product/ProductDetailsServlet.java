package product;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ProductDetailsServlet {
	@WebServlet("/ProductDetailsServlet")
	public class Product extends HttpServlet {
	    private static final long serialVersionUID = 1L;

	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        response.setContentType("text/html");
	        PrintWriter out = response.getWriter();

	        // Retrieve product ID from the form
	        int productId = Integer.parseInt(request.getParameter("productID"));

	        try {
	            // Establish database connection
	            Class.forName("com.mysql.jdbc.Driver");
	            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce", "username", "password");

	            // Prepare SQL query
	            String query = "SELECT * FROM products WHERE product_id = ?";
	            PreparedStatement pstmt = con.prepareStatement(query);
	            pstmt.setInt(1, productId);

	            // Execute query
	            ResultSet rs = pstmt.executeQuery();

	            // Display product details
	            if (rs.next()) {
	                out.println("<h2>Product Details</h2>");
	                out.println("<p>ID: " + rs.getInt("product_id") + "</p>");
	                out.println("<p>Name: " + rs.getString("product_name") + "</p>");
	                out.println("<p>Description: " + rs.getString("description") + "</p>");
	                out.println("<p>Price: $" + rs.getDouble("price") + "</p>");
	            } else {
	                out.println("<p>No product found with ID: " + productId + "</p>");
	            }

	            // Close resources
	            rs.close();
	            pstmt.close();
	            con.close();
	        } catch (Exception e) {
	            out.println("Error: " + e.getMessage());
	        }
	    }
	}
}
	    
