

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
private static final long serialVersionUID = 1L;
protected void doPost(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {
String username = request.getParameter("username");
String password = request.getParameter("password");
// Hard-coded correct credentials
String correctUsername = "user";
String correctPassword = "password";
if (username.equals(correctUsername) && password.equals(correctPassword)) {
// Successful login, redirect to dashboard
response.sendRedirect("dashboard");
} else {
// Incorrect login, show error message
response.sendRedirect("error");
}
}
}