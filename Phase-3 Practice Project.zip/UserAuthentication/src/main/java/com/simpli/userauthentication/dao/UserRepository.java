package com.simpli.userauthentication.dao;

import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.data.jpa.repository.cdi.JpaRepositoryExtension;

public abstract class UserRepository extends JpaRepositoryExtension<User, Long> {
    abstract User findByUsername(String username);
}


