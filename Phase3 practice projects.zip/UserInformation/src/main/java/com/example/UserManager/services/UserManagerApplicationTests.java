package com.example.UserManager.services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class UserManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}