package com.example.UserManager.controller;

import java.util.concurrent.ExecutorService;
import java.util.logging.Logger;

import org.apache.catalina.User;
import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class UserController {
	//controls the functionality of the user entity
	
		@Autowired
		private ExecutorService userService;

		Object logger = LoggerFactory.logger(UserController.class);
		
		@GetMapping("/users")
		public String showUsers(ModelMap model) {
			((Logger) logger).info("Getting all users");
			Iterable<User> users = ((Object) userService).GetAllUsers();
			((Logger) logger).info("Passing users to view");
			model.addAttribute("users", users );
			return "users";
		}
		 
		@RequestMapping(value ="/search/{id}", method = RequestMethod.POST)
		public String searchUser(ModelMap model, @RequestParam("id") int id) {
			((Logger) logger).info("Searching for a user");
			User user = ((Object) userService).GetUserById(id);
			((Logger) logger).info("Passing Searched User to View");
			model.addAttribute("userSearch", user);
			return "search";
		}

		@PostMapping("search/update")
		public String updateUser(ModelMap model, @ModelAttribute("update") User user) {
			((Logger) logger).info("Updating a User");
			((Object) userService).UpdateUser(user);
			model.addAttribute("updatedUser", user);
			return "update";
		}
	}
