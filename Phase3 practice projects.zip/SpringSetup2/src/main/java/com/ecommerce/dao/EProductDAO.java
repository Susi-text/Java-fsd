package com.ecommerce.dao;

import java.sql.JDBCType;
import java.sql.Wrapper;
import java.util.List;

import com.ecommerce.EProduct;

public class EProductDAO {
    JDBCType template;    
    
    public void setTemplate(JDBCType template) {    
        this.template = template;    
    }    
    
    public List<EProductDAO> getProducts(){    
        return template.query("select * from eproduct",new Wrapper<EProduct>(){    
            public EProduct mapRow(ResultSet rs, int row) throws SQLException {    
                    EProduct e=new EProduct();    
                e.setId(rs.getInt(1));    
                e.setName(rs.getString(2));    
                e.setPrice(rs.getBigDecimal(3));    
                e.setDateAdded(rs.getDate(4));    
                return e;    
            }    
        });    
    }    
}



