package com.ecommerce.controller;

public @interface Controller {

}
