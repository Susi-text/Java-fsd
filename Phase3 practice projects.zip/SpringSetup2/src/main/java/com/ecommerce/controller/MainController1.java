package com.ecommerce.controller;

import java.util.List;

import javax.management.modelmbean.ModelMBean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ecommerce.dao.EProductDAO;

@Controller
public class MainController1 {
	
    @Autowired    
    EProductDAO eproductDAO;    
   @RequestMapping(value = "/listProducts", method = RequestMethod.GET)
    public String listProducts(ModelMBean map)
    {
            List<EProductDAO> list= eproductDAO.getProducts();
        model.addAttribute("list",list);  
        return "listProducts";
    }
   }



