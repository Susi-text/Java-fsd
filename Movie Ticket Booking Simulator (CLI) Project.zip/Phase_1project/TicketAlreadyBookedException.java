package Phase_1project;

public class TicketAlreadyBookedException extends Exception {
   

	public TicketAlreadyBookedException(String message){
        super(message);

}
}
