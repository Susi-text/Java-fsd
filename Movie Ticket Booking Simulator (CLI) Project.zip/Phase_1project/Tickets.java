package Phase_1project;

import java.time.LocalDate;

public class Tickets {
	 String customerName;
	    int noOfTickets;
	    double ticketPrice;
	    LocalDate showDate;
	    String showTime;
	    String[] seatNumbers;

	    public Tickets() {
	    }

	    public Tickets(String customerName, int noOfTickets, double ticketPrice, LocalDate showDate, String showTime, String[] seatNumbers) {
	        this.customerName = customerName;
	        this.noOfTickets = noOfTickets;
	        this.ticketPrice = ticketPrice;
	        this.showDate = showDate;
	        this.showTime = showTime;
	        this.seatNumbers = seatNumbers;
	    }

	    public String getCustomerName() {
	        return customerName;
	    }

	    public void setCustomerName(String customerName) {
	        this.customerName = customerName;
	    }

	    public int getNoOfTickets() {
	        return noOfTickets;
	    }

	    public void setNoOfTickets(int noOfTickets) {
	        this.noOfTickets = noOfTickets;
	    }

	    public double getTicketPrice() {
	        return ticketPrice;
	    }

	    public void setTicketPrice(double ticketPrice) {
	        this.ticketPrice = ticketPrice;
	    }

	    public LocalDate getShowDate() {
	        return showDate;
	    }

	    public void setShowDate(LocalDate showDate) {
	        this.showDate = showDate;
	    }

	    public String getShowTime() {
	        return showTime;
	    }

	    public void setShowTime(String showTime) {
	        this.showTime = showTime;
	    }

	    public String[] getSeatNumbers() {
	        return seatNumbers;
	    }

	    public void setSeatNumbers(String[] seatNumbers) {
	        this.seatNumbers = seatNumbers;
	    }


	    @Override
	    public String toString() {
	        StringBuilder sb = new StringBuilder();
	        sb.append("-".repeat(62)).append("\n");
	        appendKeyValue(sb, "Customer Name", customerName);
	        appendKeyValue(sb, "No of Tickets", String.valueOf(noOfTickets));
	        appendKeyValue(sb, "Ticket Price", String.valueOf(ticketPrice));
	        appendKeyValue(sb, "Show Date", showDate.toString());
	        appendKeyValue(sb, "Show Time", showTime);
	        appendKeyValue(sb, "Seat Numbers", String.join(",", seatNumbers));
	        sb.append("-".repeat(62)).append("\n");

	        return sb.toString();
	    }

	    private void appendKeyValue(StringBuilder sb, String key, String value) {
	        sb.append(String.format("| %-15s | %-40s |\n", key, value));
	    }

}
