package Phase_1project;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

public class MovieTicketBooking {


	
	    static MovieBookingSystem bookingSystem = new MovieBookingSystem();
	    static Scanner scanner = new Scanner(System.in);
	    static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	    @SuppressWarnings("unused")
		private static String getValidDate(){
	        boolean isValidDate=false;
	        String selectedDate=null;
	        while (!isValidDate) {
	            System.out.print("Enter the date (e.g., 2024-01-03) :- ");
	            selectedDate = scanner.next();

	            try {
	                LocalDate date = LocalDate.parse(selectedDate, dtf);
	                isValidDate=true;
	            } catch (DateTimeParseException e) {
	                System.out.println("Invalid date format. Please enter a date in the format yyyy-MM-dd.");
	            }
	        }
	        return selectedDate;
	    }

	    private static String getValidShowTime(List<String> availableShowTimes){

	        boolean isValidShowTime = false;
	        String validShowTime = null;
	        while (!isValidShowTime) {
	            System.out.print("Enter the show time (e.g., 10:00AM) :- ");
	            validShowTime= scanner.next();
	            if(availableShowTimes.contains(validShowTime)){
	                isValidShowTime = true;
	            }
	            else {
	                System.out.println("Invalid show time");
	                System.out.print("Please ");
	            }
	        }
	        return validShowTime;

	    }


	    private static void showAvailableSeats(){
	        String selectedDate=getValidDate();
	        System.out.println("Selected Date :- "+selectedDate);
	        bookingSystem.displayShowTimes();
	        String selectedTime=getValidShowTime(bookingSystem.getShowTimes());
	        System.out.println("Selected Time :- "+selectedTime);

	        bookingSystem.displaySeatingArrangement(selectedDate, selectedTime);
	    }
	    public static void bookSeats(){
	        System.out.print("Please Enter Customer Name :- ");
	        String customerName=scanner.nextLine();

	        String selectedDate=getValidDate();
	        bookingSystem.displayShowTimes();
	        String selectedTime=getValidShowTime(bookingSystem.getShowTimes());

	        System.out.print("\nEnter the seat to book (e.g., A1 or B1-B4 or A1-A3,B1) :- ");
	        String selectedSeats = scanner.next();



	        try {
	            List<String> seatsBooked = bookingSystem.bookSeats(selectedDate, selectedTime, selectedSeats);

	            System.out.println("Booking Confirmation");
	            System.out.println("\nSelected Date  :- "+selectedDate);
	            System.out.println("Selected Time  :- "+selectedTime);
	            System.out.println("Selected Seats :- "+String.join(",",seatsBooked));

	            System.out.print("\nEnter Price of Each Ticket :- ");
	            double price=scanner.nextDouble();

	            String[] seats=new String[seatsBooked.size()];
	            Tickets ticket=new Tickets(customerName,seatsBooked.size(),price,LocalDate.parse(selectedDate,dtf),selectedTime,seatsBooked.toArray(seats));

	            System.out.println("\nNo Of Tickets :- "+ticket.noOfTickets);
	            System.out.println("Amount To Paid :- "+(ticket.getNoOfTickets()*ticket.getTicketPrice()));
	            System.out.println("Waiting for amount to be paid!! Hit Any key To Gen Ticket");
	            scanner.nextLine();
	            System.out.println(ticket);

	        }
	        catch (TicketAlreadyBookedException e) {
	            System.err.println(e.getMessage());
	            System.out.println("Please Try Again");
	        }
	        catch (InvalidTicketRangeException e) {
	            System.out.println(e.getMessage());
	            System.out.println("Please Choose Valid Tickets");
	        }
	        catch (Exception e){
	            System.out.println(e.getMessage());
	        }
	    }

	    public static void main(String[] args) {



	        System.out.println("Welcome to the Movie Booking System!");

	        while (true){
	            System.out.println("\nWhat Do You want to do?");
	            System.out.println("1. Show Available Seats as well as Show Date and Time");
	            System.out.println("2. Book Tickets");
	            System.out.println("3. Exit");

	            System.out.print("\nPlease enter your choice (1 or 2 or any key to exit) :- ");
	            int choice=scanner.nextInt();scanner.nextLine();
	            if(choice!=1 && choice!=2) {
	                scanner.close();
	                System.exit(0);
	                break;
	            }
	            switch(choice){
	                case 1:
	                    showAvailableSeats();
	                    break;
	                case 2:
	                    bookSeats();
	                    break;
	            }
	        }




	        // Close the scanner
	        scanner.close();
	    }
	}


	
