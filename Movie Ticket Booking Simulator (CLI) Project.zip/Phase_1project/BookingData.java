package Phase_1project;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BookingData {
	private Map<String, Map<String, List<String>>> bookedSeatsByDate;

    public BookingData() {
        bookedSeatsByDate = new HashMap<>();
    }

    public void bookSeat(String date, String showTime, String seat) {
        bookedSeatsByDate
                .computeIfAbsent(date, k -> new HashMap<>())
                .computeIfAbsent(showTime, k -> new ArrayList<>())
                .add(seat);
    }

    public boolean isSeatBooked(String date, String showTime, String seat) {
        return bookedSeatsByDate
                .getOrDefault(date, Collections.emptyMap())
                .getOrDefault(showTime, Collections.emptyList())
                .contains(seat);
    }
}


