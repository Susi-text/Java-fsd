package Phase_1project;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MovieBookingSystem {
	private final BookingData bookingData;
    private final Theatre theatre;

    public MovieBookingSystem() {
        bookingData = new BookingData();
        theatre = new Theatre();
    }

    public void displayShowTimes() {
        System.out.print("Available times: ");
        String showTimes = String.join("    ", theatre.showTimes);
        System.out.println(showTimes);
    }

    public void displaySeatingArrangement(String selectedDate, String selectedShowTime) {
        System.out.println("Seating Arrangement for " + selectedDate + " at " + selectedShowTime + ":");
        for (int i = 0; i < theatre.seats.length; i++) {
            for (int j = 0; j < theatre.seats[i].length; j++) {
                String seat = theatre.seats[i][j];
                boolean isBooked = bookingData.isSeatBooked(selectedDate, selectedShowTime, seat);
                if(isBooked) {
                    System.out.print("\u001B[31m" + seat + " " + "\u001B[0m");
                }
                else{
                    System.out.print(seat+" ");
                }
            }
            System.out.println();
        }
    }
    public List<String> getSeats(String seatsInput) throws  InvalidTicketRangeException {
        List<String> allSeats=new ArrayList<>();
        String[] seatRanges = seatsInput.split(",");
        for (String seatRange : seatRanges) {
            String[] seats = seatRange.split("-");
            if (seats.length == 1) {
                allSeats.add(seats[0]);
            } else if (seats.length == 2) {
                String startSeat=seats[0];
                String endSeat=seats[1];
                char startRow = startSeat.charAt(0);
                char endRow = endSeat.charAt(0);
                if(startRow!=endRow){
                    throw new InvalidTicketRangeException("Invalid Ticket Range "+seatRange);
                }
                int startCol = Integer.parseInt(startSeat.substring(1));
                int endCol = Integer.parseInt(endSeat.substring(1));
                if (startCol>4 || endCol<=startCol){
                    throw new InvalidTicketRangeException("Invalid Ticket Range "+seatRange);
                }
                for(int i=startCol;i<=endCol;i++){
                    allSeats.add(String.valueOf(startRow)+i);
                }
            }
        }
        return allSeats;
    }

    private List<String> checkAvailability(String selectedDate, String selectedShowTime, String seatInp) throws TicketAlreadyBookedException, InvalidTicketRangeException {
        List<String> selectedSeats = getSeats(seatInp);
        for(String seat : selectedSeats){
            if(bookingData.isSeatBooked(selectedDate,selectedShowTime,seat)){
                throw new TicketAlreadyBookedException("Ticket :"+seat+" is already Booked");
            }
        }
        return selectedSeats;
    }

    public List<String> bookSeats(String selectedDate, String selectedShowTime, String seatInp) throws TicketAlreadyBookedException, InvalidTicketRangeException {

        List<String> selectedSeats = checkAvailability(selectedDate,selectedShowTime,seatInp);
        for(String seat:selectedSeats){
            bookingData.bookSeat(selectedDate,selectedShowTime,seat);
        }
        return selectedSeats;
    }

    public List<String> getShowTimes(){
        return Arrays.stream(theatre.showTimes).collect(Collectors.toList());
    }

}

	