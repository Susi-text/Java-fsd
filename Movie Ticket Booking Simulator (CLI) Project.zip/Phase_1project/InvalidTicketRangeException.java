package Phase_1project;

public class InvalidTicketRangeException extends Exception {
    

	public InvalidTicketRangeException(String message){
        super(message);

}
}
