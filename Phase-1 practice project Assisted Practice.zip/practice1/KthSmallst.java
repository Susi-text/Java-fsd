package practice1;

public class KthSmallst {

}
