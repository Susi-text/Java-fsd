package project_1;

public class LongestIncreasingSubsequence {
	 public static void main(String[] args) {
	        int[] arr = {10, 22, 9, 33, 21, 50, 41, 60, 80};
	        int length = arr.length;

	        int result = longestIncreasingSubsequence(arr, length);
	        System.out.println("Length of Longest Increasing Subsequence: " + result);
	    }

	    private static int longestIncreasingSubsequence(int[] arr, int length) {
	        int[] lis = new int[length];
	        int max = 0;

	        for (int i = 0; i < length; i++) {
	            lis[i] = 1;
	            for (int j = 0; j < i; j++) {
	                if (arr[i] > arr[j] && lis[i] < lis[j] + 1) {
	                    lis[i] = lis[j] + 1;
	                }
	            }
	            if (lis[i] > max) {
	                max = lis[i];
	            }
	        }

	        return max;
	    }

}
