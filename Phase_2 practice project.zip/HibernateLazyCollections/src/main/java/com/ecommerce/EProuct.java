package com.ecommerce;

import java.math.BigDecimal;
import java.sql.Date;

import org.apache.jasper.tagplugins.jstl.core.Set;
import org.hibernate.mapping.List;

import net.bytebuddy.description.annotation.AnnotationDescription;

public class EProuct {
    private long ID;
    private String name;
    private BigDecimal price;
    private Date dateAdded;
    private List colors;
    private Set finance;
    private AnnotationDescription pdescrip;
    
    public void EProduct() {
            
    }
    
    public long getID() {return this.ID; }
    public String getName() { return this.name;}
    public BigDecimal getPrice() { return this.price;}
    public Date getDateAdded() { return this.dateAdded;}
    public List getColors() { return this.colors;}
    public Set getFinance() { return this.finance;}
    public AnnotationDescription getPdescrip() { return this.pdescrip;}
    
    public void setID(long id) { this.ID = id;}
    public void setName(String name) { this.name = name;}
    public void setPrice(BigDecimal price) { this.price = price;}
    public void setDateAdded(Date date) { this.dateAdded = date;}
    public void setColors(List colors) { this.colors = colors;}
    public void setFinance(Set finance) { this.finance = finance;}
    public void setPdescrip(AnnotationDescription pdescrip) { this.pdescrip = pdescrip;}
}




}
