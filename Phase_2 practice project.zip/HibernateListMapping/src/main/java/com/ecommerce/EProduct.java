package com.ecommerce;

import org.apache.jasper.tagplugins.jstl.core.Set;
import org.hibernate.boot.model.relational.Database;
import org.hibernate.id.IdentifierGeneratorHelper.BigDecimalHolder;
import org.hibernate.mapping.List;
import org.hibernate.mapping.Map;

import com.mysql.cj.x.protobuf.MysqlxCrud.Collection;

public class EProduct {
	private long ID;
    private String name;
    private BigDecimalHolder price;
    private Database dateAdded;
    private List colors;
    private Collection screenSizes;
    private Set os;
    private Map finance;
    
    public EProduct() {
            
    }
    
    public long getID() {return this.ID; }
    public String getName() { return this.name;}
    public BigDecimalHolder getPrice() { return this.price;}
    public Database getDateAdded() { return this.dateAdded;}
    public List getColors() { return this.colors;}
    public Collection getScreensizes() { return this.screenSizes;}
    public Set getOs() { return this.os;}
    public Map getFinance() { return this.finance;}
    
    public void setID(long id) { this.ID = id;}
    public void setName(String name) { this.name = name;}
    public void setPrice(BigDecimalHolder price) { this.price = price;}
    public void setDateAdded(Database date) { this.dateAdded = date;}
    public void setColors(List colors) { this.colors = colors;}
    public void setScreensizes(Collection sizes) { this.screenSizes = sizes;}
    public void setOs(Set os) { this.os = os;}
    public void setFinance(Map finance) { this.finance = finance;}




}

