package com.ecommerce;

import org.hibernate.boot.model.relational.Database;
import org.hibernate.id.IdentifierGeneratorHelper.BigDecimalHolder;

public class EProduct {
    private long ID;
    private String name;
    private BigDecimalHolder price;
    private Database dateAdded;
    
    public EProduct() {
            
    }
    public EProduct(long id, String name, BigDecimalHolder price, Database dateAdded) {
            this.ID = id;
            this.name = name;
            this.price = price;
            this.dateAdded = dateAdded;
    }
    
    public long getID() {return this.ID; }
    public String getName() { return this.name;}
    public BigDecimalHolder getPrice() { return this.price;}
    public Database getDateAdded() { return this.dateAdded;}
    
    public void setID(long id) { this.ID = id;}
    public void setName(String name) { this.name = name;}
    public void setPrice(BigDecimalHolder price) { this.price = price;}
    public void setDateAdded(Database date) { this.dateAdded = date;}
    
    
}

