package com.ecommerce;

import org.hibernate.boot.model.relational.Database;
import org.hibernate.id.IdentifierGeneratorHelper.BigDecimalHolder;
import org.hibernate.sql.Update;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity  
@Table(name= "eproduct")   
public class EProduct {      
	  
	        @Id @GeneratedValue   
	        @Column(name = "ID")
	        private long ID;
	        
	        @Column(name = "name")
	        private String name;
	        
	        @Column(name = "price")
	        private BigDecimalHolder price;
	        
	        @Column(name = "date_added")
	        private Database dateAdded;  
	            
	        public long getID() {return this.ID; }
	        public String getName() { return this.name;}
	        public BigDecimalHolder getPrice() { return this.price;}
	        public Database getDateAdded() { return this.dateAdded;}
	        
	        public void setID(long id) { this.ID = id;}
	        public void setName(String name) { this.name = name;}
	        public void setPrice(BigDecimalHolder price) { this.price = price;}
	        public void setDateAdded(Database date) { this.dateAdded = date;}    
	}   

}
